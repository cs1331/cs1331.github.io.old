# pq-cars
Calculate the range of cars based on gas mileage, etc.

Topics:
- inheritance
- polymorphism
- object oriented design

Instructions are in `index.md`
