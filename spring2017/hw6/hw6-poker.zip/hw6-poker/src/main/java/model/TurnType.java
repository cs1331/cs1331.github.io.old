package model;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public enum TurnType {
    CALL, RAISE, FOLD
}