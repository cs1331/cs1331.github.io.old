package view;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public class PokerGame extends Application {

    public static Stage primaryStage;

    /**
     * this method is called upon running/launching the application
     * this method should display a scene on the stage
     * @param ps The primary Stage
     */
    public void start(Stage ps) {
        primaryStage = ps;

        /*
        TODO: - Display the StartScreen
              - Set the name of the stage
         */
    }

    /**
     * Starts the Game
     * This is called by StartScreen whenever it is done and the GameScreen,
     * ControlPane, and Console should be displayed
     * @param name The name of the human player
     */
    public void startGame(String name) {
        /*
        TODO: - Instantiate The PokerGameController
              - Display the GameScreen, ControlPane, and Console
                  - What layout should be used?
         */
    }

    /**
     * This is called by PokerGameController whenever updates are made. You
     * must handle updating the UI here.
     */
    public void updatesMade() {
        /*
        TODO: Update the UI (GameScreen and ControlPane). Don't forget to
        differentiate between when the GameState is DONE vs AI_BET vs HUMAN_BET
            - When GameState is DONE show all the cards on the table otherwise
              only show the cards in the middle and the user's cards on the
              bottom also show the start new round button
            - When AI_BET disable the buttons in the control pane otherwise
              make them be enabled
            - When 
         */
    }

    /**
     * This is the main method that launches the javafx application
     * @param args command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}