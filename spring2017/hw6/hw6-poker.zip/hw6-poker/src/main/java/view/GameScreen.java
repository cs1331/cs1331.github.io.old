package view;

import javafx.scene.layout.BorderPane;
import viewcontroller.PokerGameController;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public class GameScreen extends BorderPane {

    /**
     * GameScreen's constructor
     * @param controller The PokerGameController to interact with
     */
    public GameScreen(PokerGameController controller) {
        /*
        TODO: - Set this GameScreen to have PlayerAreas top, left, right, and
                bottom
                  - Use the controller to get the correct Player for each
                  PlayerArea
              - Set the center to be a BoardArea
                  - Use the controller to get the Board for the BoardArea
         */
    }

    /**
     * This method is called whenever normal updates to the UI need to be made.
     */
    public void updatesMade() {
        /*
        TODO: - Update the players and and the board.
              - Only the player on bottom (the user) should have its cards'
                details shown
         */
    }

    /**
     * This method is called whenever a round of poker ends
     */
    public void endOfRound() {
        /*
        TODO: - Update the players and Board
              - All Players' Cards' details need to be shown
         */
    }

}