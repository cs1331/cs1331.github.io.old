package view;

import javafx.scene.layout.HBox;
import model.Board;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public class BoardArea {

    private HBox pane;

    private Board board;

    /**
     * Constructor for the board's display
     * @param  board The Board object that contains data associated with the
     * board
     */
    public BoardArea(Board board) {
        this.board = board;

        /*
        TODO: - Instantiate the pane
              - Add 5 CardViews to the pane
              - Add a pot label to the pane

              We store board in instance data because we use it to get the
              information we need for updating the UI. Look at the methods
              in Board.java.
         */
    }

    /**
     * Getter for the HBox that all UI elements are on
     * @return the HBox that all Board UI elements are on
     */
    public HBox getPane() {
        return pane;
    }

    /**
     * Updates UI elements
     */
    public void update() {
        /*
        TODO: - update the cards and pot
              - Don't forget to hide or show the cards as necessary
              - Look at the methods in Board.java to see how many Cards you
              should show or hide.
         */
    }

}