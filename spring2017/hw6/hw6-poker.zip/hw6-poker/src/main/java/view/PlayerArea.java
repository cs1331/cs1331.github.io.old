package view;

import javafx.scene.layout.Pane;

import model.Player;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public abstract class PlayerArea {

    private Pane pane;

    private Player player;

    /**
     * PlayerArea's constructor
     * @param  pane   The Pane where all UI elements will be added. The type of
     * pane is decided by subclasses
     * @param  player The Player who's information will be tracked
     */
    public PlayerArea(Pane pane, Player player) {
        this.pane = pane;
        this.player = player;

        /*
        TODO: - Add Two Card Views and the name/chips/out of play indicator to
                the pane
         */
    }

    /**
     * Getter for the Pane that contains all of the UI elements.
     * @return The Pane that contains all of the UI elements.
     */
    public Pane playerPane() {
        return pane;
    }

    /**
     * This method is called whenever an update to the UI needs to be made.
     * @param showDetails is true whenever the details of the front of the
     * cards are supposed to be shown false otherwise
     */
    public void update(boolean showDetails) {
        /*
        TODO: - Always update the chips
              - Always check if the CardView's Card needs to be updated and
                update it if necessary
              - Always check if the player is out of play and if so show the
                out of play indicator
              - If the player is out of play then hide the Card
              - If the player is in play but showDetails is false hide the
                details of the card
              - If the player is in play and showDetails is true show the Card
         */
    }

}