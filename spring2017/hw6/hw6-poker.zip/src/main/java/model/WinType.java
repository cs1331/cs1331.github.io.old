package model;

/**
 * @author CS1331 TAs
 * @version 1.0
 *
 * Represents the different types of Wins
 */
public enum WinType {
    SINGLE, MULTIPLE, LAST_LEFT
}