package view;

import javafx.scene.layout.HBox;
import viewcontroller.PokerGameController;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public class ControlPane extends HBox {

    private PokerGameController cont;

    /**
     * Constructor for ControlPane
     * @param  cont The PokerGameController to interact with
     */
    public ControlPane(PokerGameController cont) {
        this.cont = cont;
        
        /*
        TODO: - Add all of the Buttons and the Label to ControlPane
         */
    }

    /**
     * Called whenever it becomes the player's turn again
     */
    public void playerTurn() {
        /*
        TODO: - Enable all of the buttons
         */
    }

    /**
     * Method called when the round ends.
     */
    public void endOfRound() {
        /*
        TODO: - Show the Start New Round Button
         */
    }

}