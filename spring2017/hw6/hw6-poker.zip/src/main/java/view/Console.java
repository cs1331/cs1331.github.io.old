package view;

import javafx.scene.control.ScrollPane;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public class Console extends ScrollPane {

    private static Console instance;

    /**
     * Console's constructor. Set's the static instance variable.
     */
    public Console() {
        instance = this;

        /*
        TODO: - Create a label
              - Set wrap text to true
              - Set this Console's content to the Label
         */
    }

    /**
     * Add's text to the top of the console. (Doesn't get rid of
     * text that is already there!)
     * @param newText is the text to add to the top of the console
     */
    public void addText(String newText) {
        /*
        TODO: - Add text to the label AT THE TOP
              - To make things nicer you can use setVvalue(0) in ScrollPane
                (Not required but really nice)
         */
    }

    /**
     * Clears the console of any text
     */
    public void clear() {
        /*
        TODO: - Clear the label of text
         */
    }

    /**
     * Static method that adds a message into the current
     * {@value  instance}
     * @param message The message to add
     */
    public static void putMessage(String message) {
        instance.addText(message);
    }

    /**
     * Clears the console of the current {@value instance}
     */
    public static void clearLog() {
        instance.clear();
    }
}