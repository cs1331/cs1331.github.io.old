package view;

import javafx.scene.layout.StackPane;

/**
 * @author CS1331 TAs
 * @version 1.0
 */
public class StartScreen extends StackPane {

    // Path to the image file for the background
    private static final String BACK_LOCATION = "File:./src/main/res"
        + "/poker-game-background.png";

    /**
     * StartScreen's constructor
     * @param cont The PokerGame to interact with
     */
    public StartScreen(PokerGame cont) {
        /*
        TODO: - Add the background to this StartScreen
              - Add the start button to this StartScreen
         */
    }

}