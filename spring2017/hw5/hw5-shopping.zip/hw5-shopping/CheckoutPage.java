/**
 * Represents the checkout page
 *
 * @author Isabella Plonk
 * @author Your name
 * @version 1.0
 */
public class CheckoutPage {

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("----------------------------------------------------------"
            + "------------\n");
        s.append("                           KYLIE COSMETICS℠\n");
        s.append("----------------------------------------------------------"
            + "------------\n");
        int i = 1;
        for (Product product : shoppingCart) {
            s.append("(" + i + ") " + product + "\n");
            i++;
        }
        s.append(String.format("Total number of items: %d%n",
            shoppingCart.size()));
        s.append(String.format("Subtotal: $%.2f%n", getSubtotal()));
        s.append(String.format("Shipping: $%.2f%n", getShipping()));
        s.append("----------------------------------------------------------"
            + "------------\n");
        s.append(String.format("Total: $%.2f%n", getTotal()));
        s.append("Enter 'pay' to checkout or 'back' to"
                + " return to the main menu.\n");
        s.append("Enter the number of an item to remove it"
                + " from the shopping cart.\n");
        return s.toString();
    }
}