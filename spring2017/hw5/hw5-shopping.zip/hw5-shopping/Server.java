import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
/**
 * Represents the website server
 *
 * @author Isabella Plonk
 * @author Your name
 * @version 1.0
 */
public class Server {

    /**
     * Scans in all of the products
     * from a text file into an array list
     * @return an array list of all of the products
     */
    public static ArrayListInterface<Product> getProducts() {
        try {
            ArrayListInterface<Product> products = new MyArrayList<>();
            Scanner csv = new Scanner(new File("products.csv"));
            csv.nextLine(); // Skip the header
            while (csv.hasNext()) {
                String[] line = csv.nextLine().split("-");
                Product product;
                if (line[0].equals("Kyshadow")) {
                    product = new Kyshadow(line[1],
                        Boolean.valueOf(line[2]));
                } else if (line[0].equals("Kyliner")) {
                    product = new Kyliner(line[1],
                        Boolean.valueOf(line[2]));
                } else {
                    product = new LipKit(line[1],
                        Boolean.valueOf(line[2]));
                }
                products.add(product);
            }
            return products;
        } catch (FileNotFoundException e) {
            System.out.println("Check location of products.csv.");
            System.exit(1);
        }
        return new MyArrayList<>();
    }
}