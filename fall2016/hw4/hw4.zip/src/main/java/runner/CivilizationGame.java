package runner;

import view.UI;

public class CivilizationGame {
    public static void main(String[] args) throws Exception {
        UI.start();
    }
}
