package model;

class View {
    public static void main(String[] args) {
        Map map = new Map(10, 10);
        System.out.println(map);
    }
}
