package model;

import javafx.scene.image.Image;

/**
 * Created by RuYiMarone on 11/11/2016.
 */
public interface Viewable {

    Image getImage();

}
