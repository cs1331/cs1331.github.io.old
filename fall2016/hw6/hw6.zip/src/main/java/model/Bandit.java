package model;

/**
 * Created by RuYiMarone on 10/24/2016.
 */
public class Bandit extends Civilization {
    public Bandit() {
        super("Bandits");
    }
}
