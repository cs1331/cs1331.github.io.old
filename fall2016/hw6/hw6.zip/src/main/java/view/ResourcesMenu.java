package view;

import controller.GameController;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import model.Civilization;

public class ResourcesMenu {
    
    /**
    * creates a resource bar and display the current state of 
    * your civilization's resouces
    */
    public ResourcesMenu() {
        //TODO
    }
    /**
    * should update all the resouce values to the current
    * state of your resource values
    */
    public void update() {
        
    }
    /**
    * updates the resource bar and returns the resource bar
    * @return a hbox representation of the resource bar
    */
    public HBox getRootNode() {
        //TODO
    }
}