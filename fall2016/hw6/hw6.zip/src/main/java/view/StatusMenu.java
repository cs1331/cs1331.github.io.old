package view;

public class StatusMenu extends AbstractMenu {
    /**
     * Concerte implementation of abstract menu, could be useful for
     * other unit information
     */
    public StatusMenu() {
    	//TODO
    }
}
