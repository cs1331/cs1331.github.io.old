package view;

import controller.GameController;
import model.Convertable;
import model.MapObject;
import model.TerrainTile;

/**
 * Created by RuYiMarone on 11/11/2016.
 */
public class WorkerMenu extends AbstractMenu {
    /**
    * There should be a convert and move button
    * as well as the functions associated with those
    * buttons
    */
    public WorkerMenu() {
        //TODO
    }
}
