package registration;

/**
 * Represents of a student able to register for courses
 *
 * @author YOURIDHERE
 * @version 1.0
 */
public class Student {

    /**
     * A wrapper method for course's addStudent method
     *
     * @param course The course that the student is attempting to register for
     * @return Whether or not the operation was successful
     */
    public boolean signUp(Course course) {
        return course.addStudent(this);
    }
    /**
     * Removes a course from waitlists classes and add it to courses
     *
     * @param course the course in which the student has been
     * promoted from the waitlist
     *
     * @return Whether or not the operation was successful
     */
    protected boolean promotedFromWaitlist(Course course) {
        for (int i = 0; i < numCoursesWaitlisted; i++) {
            if (course == waitlists[i]) {
                for (int j = i + 1; j < numCoursesWaitlisted; j++) {
                    waitlists[j - 1] = waitlists[j];
                }
                numCoursesWaitlisted--;
                waitlists[numCoursesWaitlisted] = null;
                credits -= course.getCredits();
                register(course);
                return true;
            }
        }
        return false;
    }
}
