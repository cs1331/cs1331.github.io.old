import java.util.Scanner;
public class PieShop {

	//your code here

	public static void addToCart(Pie p) {
		//your code here
	}

	public static double sum() {
		//your code here
	}

	/*
	*** DO NOT EDIT ANYTHING BELOW THIS LINE ***
	*/
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		boolean keepGoing = true;
		System.out.println("Welcome to the Pie Shop!");
		while (keepGoing) {
			String choice = home(scan);
			switch (choice) {
				case "1":
					System.out.print("\n\n");
					pieMenu(scan, true);
					break;
				case "2":
					System.out.print("\n\n");
					pieMenu(scan, false);
					break;
				case "3":
					System.out.print("\n\n");
					System.out.print("Cart contents: ");
					for (int i = 0; i < numPies; i++) {
						System.out.print(cart[i]);
						if (i != numPies - 1) {
							System.out.print(", ");
						}
					}
					System.out.println();
					break;
				case "4":
					double sum = sum();
					System.out.print("\n\n");
					System.out.printf("Thank you! Your total is $%.2f.%n"
						+ "Please proceed to the counter to pick up your order.", sum);
					keepGoing = false;
					break;
				default:
					System.out.println("\n\nPlease enter a valid choice.");
					break;
			}
			System.out.print("\n\n");

		}
	}

	private static String home(Scanner scan) {
		System.out.println("Please choose an option:\n"
			+ "1. Buy a slice\n2. Buy a whole pie\n3. View cart\n4. Check out\n");
		return scan.nextLine();
	}

	private static void pieMenu(Scanner scan, boolean b) {
		System.out.println("Please enter the number of "
			+ "the flavor of pie you would like to purchase:\n"
			+ "1. Banana cream\n2. Pumpkin\n3. Apple\n4. Key lime\n5. Chocolate\n");
		String choice = scan.nextLine();
		switch (choice) {
			case "1":
				addToCart(new Pie("Banana cream", b));
				break;
			case "2":
				addToCart(new Pie("Pumpkin", b));
				break;
			case "3":
				addToCart(new Pie("Apple", b));
				break;
			case "4":
				addToCart(new Pie("Key lime", b));
				break;
			case "5":
				addToCart(new Pie("Chocolate", b));
				break;
			default:
				System.out.println("\n\nPlease enter a valid choice.\n\n");
				pieMenu(scan, b);
				break;
		}
	}
}