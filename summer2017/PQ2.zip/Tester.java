public class Tester {
	public static void main(String[] args) {
		// The output of this file should be:
		// My name is Harry and I am a wizard in the GRYFFINDOR house.
		// My name is Ron and I am a wizard in the GRYFFINDOR house.
		// My name is Luna and I am a wizard in the RAVENCLAW house.
		// My name is Filch and I am a(n) caretaker.
		// Harry casts patrificus totalus!
		// Ron casts expecto patronum and a jack russell terrier patronus appears!
		// Harry triumphed over Ron in a duel!
		// Luna triumphed over Ron in a duel!
		// false
		// true

		Wizard wizard1 = new Wizard("Harry", House.GRYFFINDOR, 1000, "stag");
		Wizard wizard2 = new Wizard("Ron", House.GRYFFINDOR, 800, "jack russell terrier");
		Wizard wizard3 = new Wizard("Luna", House.RAVENCLAW, 900, "hare");
		Wizard wizard4 = new Wizard("Harry", House.HUFFLEPUFF, 1000, "moose");
		Person muggle1 = new Muggle("Filch", "caretaker");

		System.out.println(wizard1);
		System.out.println(wizard2);
		System.out.println(wizard3);
		System.out.println(muggle1);

		wizard1.castSpell("patrificus totalus");
		wizard2.castSpell("expecto patronum");
		wizard2.duel(wizard1);
		wizard3.duel(wizard2);

		System.out.println(wizard2.equals(wizard3));
		System.out.println(wizard1.equals(wizard4));
	}
}