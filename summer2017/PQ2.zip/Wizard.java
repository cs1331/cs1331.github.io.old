public class Wizard {

	//your code here

	public Wizard(String name, House house, int skill, String patronus) {
		//your code here
	}

	public void duel(Wizard w) {
		//your code here
	}

	public String toString() {
		//your code here
	}

	//your code here
}