public class Muggle {
	
	//your code here

	public Muggle(String name, String occupation) {
		//your code here
	}

	public String toString() {
		//your code here
	}

}