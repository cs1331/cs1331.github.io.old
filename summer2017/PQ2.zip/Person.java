public class Person {
	
	//your code here

	public Person(String name) {
		//your code here
	}

	/*
	* DO NOT EDIT BELOW THIS LINE
	*/
	public String toString() {
		return String.format("My name is %s", name);
	}

	public String getName() {
		return name;
	}
}