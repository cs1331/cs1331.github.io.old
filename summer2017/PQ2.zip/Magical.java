public interface Magical {
	
	void castSpell(String spell);

}