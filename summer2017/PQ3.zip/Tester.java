import java.util.Set;
import java.util.HashSet;

public class Tester {

    public static void main(String[] args) {
        // The output of the following code should be:
        // null
        // toothless
        // null
        // null
        // null
        // jigglypuff
        // null
        // [1, 2, 3, 8]
        //
        // null
        // yoshi
        // null
        // toad
        // null
        // null
        // zelda
        // lufy
        // [light, bowser, patrick]
        //
        HashMap<Integer,String> map = new HashMap<>(10);
        System.out.println(map.put(1, "toothless"));
        System.out.println(map.put(1, "spongebob"));
        System.out.println(map.put(2, "mario"));
        System.out.println(map.put(3, "jigglypuff"));
        System.out.println(map.put(8, "link"));
        System.out.println(map.get(3));
        System.out.println(map.get(5));
        System.out.println(map.keySet());

        System.out.println();

        HashMap<String,String> map1 = new HashMap<>(5);
        System.out.println(map1.put("bowser", "yoshi"));
        System.out.println(map1.put("bowser", "zelda"));
        System.out.println(map1.put("falcon", "toad"));
        System.out.println(map1.put("patrick", "vegeta"));
        System.out.println(map1.put("light", "lufy"));
        System.out.println(map1.get("falcon"));
        System.out.println(map1.get("bowser"));
        System.out.println(map1.get("light"));
        System.out.println(map1.keySet());
    }

}