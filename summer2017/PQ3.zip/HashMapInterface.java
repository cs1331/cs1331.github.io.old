import java.util.Set;
/**
 * This HashMapInterface defines the behavior for your HashMap.
 * @author Heather
 * @version 1
 */
public interface HashMapInterface<K,V> {

    /**
     * This method adds this key-value pair to the HashMap using the key's
     * hashcode. If the spot that corresponds with this key's hashcode is
     * already taken, this new key-value pair should REPLACE the old key-value
     * pair. This method then returns the VALUE from the OLD key-value pair or
     * null if that spot in the HashMap was empty.
     *
     * It is guaranteed that a NON-NULL key and a NON-NULL value will be
     * passed in during testing.
     *
     * @param key the key to be added
     * @param value the value to be added
     * @return the value of the old key-value pair or null
     */
    V put(K key, V value);

    /**
     * This method retrieves and returns the VALUE associated with the passed
     * in KEY. If there is no mapping for this key in this HashMap, this
     * method should return null.
     *
     * It is guaranteed that a NON-NULL key will be passed in during testing.
     *
     * @param key the key of the key-value pair
     * @return the value corresponding to the passed in key
     */
    V get(K key);

    /**
     * This method returns a Set containing all of the keys in this HashMap.
     * If the HashMap is empty it should return an empty Set.
     *
     * This is the only method in which you may use ANY Set implementation
     * provided in the java.util package.
     *
     * @return a set containing all of the keys in this HashMap
     */
    Set<K> keySet();

}