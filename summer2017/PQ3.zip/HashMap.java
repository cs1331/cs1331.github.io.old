import java.util.Set;
import java.util.HashSet;

public class HashMap<K,V> implements HashMapInterface<K,V> {

    /**
     * Represents a key-value pairing.
     */
    private class Pair<K,V> {
        private K key;
        private V value;

        public Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    private Pair<K,V>[] backingArr;
}