/**
* MinionList class.
* @author Heather
* @version 1
*/
public class MinionList {

    private Node head;

    /**
     * Node class.
     */
    private class Node {
        private Minion data;
        private Node next;

        public Node(Minion data, Node next) {
            this.data = data;
            this.next = next;
        }
    }

    /**
     * Checks if list is empty.
     * @return true if this list has no elements, false otherwise.
     */
    public boolean isEmpty() {
        return head == null;
    }
}