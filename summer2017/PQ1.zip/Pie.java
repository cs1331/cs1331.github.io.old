public class Pie {

	//your code here

	public Pie(String flavor, boolean isSlice) {
		//your code here
	}

	public double price() {
		//your code here
	}


	/*
	*** DO NOT EDIT ANYTHING BELOW THIS LINE ***
	*/
	public String toString() {
		String type = isSlice ? "Slice" : "Whole pie";
		double price = price();
		return String.format("%s %s $%.2f", flavor, type, price);
	}
}