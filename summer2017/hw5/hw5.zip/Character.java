/**
 * @author Yashveer Singh
 * @version 1.0
 */
public class Character /*YOUR CODE HERE*/ {

	/*YOUR CODE HERE*/


	/**
	 * Should return a string in the format used in the below example.
	 *
	 * Name: Jon; Combat Skill: 4; Intel: 7; Special Power: no; Dragons: 0
	 *
	 * If hasSpecialPower is false, "Special Power: " should say no
	 * afterward. If hasSpecialPower is true, "SpecialPower: "
	 * should say yes afterward.
	 * @return a String representation of the Character
     */
	public String toString() {
		//YOUR CODE HERE//
		return null;
	}



}