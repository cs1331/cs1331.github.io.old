import java.util.NoSuchElementException;
import java.util.Iterator;

/**
 * @author Yashveer Singh
 * @version 1.0
 */
public class ComparableCollection</*YOUR CODE HERE*/> implements CollectionInterface<T>, Iterable<T> {
	
	//YOUR CODE HERE//

}